package org.erp.mapper;

public interface TestMapper {
	public String getTime();
}
